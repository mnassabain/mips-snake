Le code principal concernant les règles du jeu (cannibalisme, obstacle, mur...) est bien optimisé.
Cependant la partie concernant l'affichage du score l'est moins
(on a essayé de l'optimisé mais malheureusement ça n'a pas fonctionnée, et faute de temps on a pa pu debugger).
On a également essayé de faire des niveaux, plus on passe les niveaux et plus le serpent va vite,
mais une fois arrivé au level 2 la vitesse n'augmente plus (code en commentaire).